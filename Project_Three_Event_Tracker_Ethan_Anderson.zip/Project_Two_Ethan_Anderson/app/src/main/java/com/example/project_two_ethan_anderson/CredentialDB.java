package com.example.project_two_ethan_anderson;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class CredentialDB extends SQLiteOpenHelper {

    private static final String name = "credentials.db";
    private static final int version = 1;
    private static final SQLiteDatabase.CursorFactory factory = null;
    private static final String tableName = "credentials";
    private static final String id = "id";
    private static final String username = "username";
    private static final String password = "password";


    // Constructor
    public CredentialDB(Context context) {
        super(context, name, factory, version);
    }

    // Create table
    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + tableName + "(" + id +
                " INTEGER PRIMARY KEY AUTOINCREMENT, " + username + " TEXT, " + password + " TEXT)";
        db.execSQL(query);

    }

    // Delete table if it exists
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String query = "DROP TABLE IF EXISTS " + tableName;
        db.execSQL(query);
        onCreate(db);

    }

    // Add user credentials to table
    public void createUser(String username, String password, SQLiteDatabase db, Context context) {
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(context, "Please enter a username and password",
                    Toast.LENGTH_SHORT).show();
        }
        else
        {
            String query = "INSERT INTO " + tableName + " (" + CredentialDB.username + ", "
                    + CredentialDB.password + ") " + "VALUES (?, ?)";
            db.execSQL(query, new String[]{username, password});
            Toast.makeText(context, "User created",
                    Toast.LENGTH_SHORT).show();
        }
    }

    // Verify user credentials for login
    public boolean verifyUser(String username, String password, SQLiteDatabase db, Context context) {
        String query = "SELECT * FROM " + tableName + " WHERE " + CredentialDB.username +
                " = ? AND "
                + CredentialDB.password + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username, password});

        if (cursor.getCount() <= 0) {
            Toast.makeText(context, "Invalid username or password",
                    Toast.LENGTH_SHORT).show();
            return false;
        }
        else
        {
            Toast.makeText(context, "Login successful",
                    Toast.LENGTH_SHORT).show();
            return true;
        }
    }
}
