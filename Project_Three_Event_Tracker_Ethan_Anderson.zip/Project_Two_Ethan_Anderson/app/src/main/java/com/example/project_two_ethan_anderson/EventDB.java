package com.example.project_two_ethan_anderson;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class EventDB extends SQLiteOpenHelper {

    private static final String name = "events.db";
    private static final int version = 1;
    private static final SQLiteDatabase.CursorFactory factory = null;
    public static final String tableName = "events";
    private static final String id = "id";
    private static final String eventName = "event_name";
    private static final String eventDate = "event_date";
    public String selectedDate = "";


    // Constructor
    public EventDB(Context context) {
        super(context, name, factory, version);
    }

    // Create Table
    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + tableName + "(" + id +
                " INTEGER PRIMARY KEY AUTOINCREMENT, " + eventName + " TEXT, " + eventDate + " TEXT)";
        db.execSQL(query);

    }

    // Update Table
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String query = "DROP TABLE IF EXISTS " + tableName;
        db.execSQL(query);
        onCreate(db);

    }

    // Add event to table
    public void addEvent(String eventName, String eventDate, SQLiteDatabase db, Context context) {
        if (eventName.isEmpty() || eventDate.isEmpty()) {
            Toast.makeText(context, "Please enter event name and date",
                    Toast.LENGTH_SHORT).show();
        }
        else
        {
            String query = "INSERT INTO " + tableName + " (" + EventDB.eventName + ", "
                    + EventDB.eventDate + ") " + "VALUES (?, ?)";
            db.execSQL(query, new String[]{eventName, eventDate});
            Toast.makeText(context, "Event Created",
                    Toast.LENGTH_SHORT).show();
        }
    }

    // Delete event from table
    public void deleteEvent() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(tableName, null, null);
        db.close();
    }

    // Update event in table
    public void updateEvent(String oldEventName, String newEventName) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "UPDATE " + tableName + " SET event_name = ? WHERE event_name = ?";
        db.execSQL(query, new String[]{newEventName, oldEventName});
        db.close();
    }

    // Get event by date using cursor data
    public Cursor getEventsByDate(String selectedDate) {
        String query = "SELECT * FROM " + tableName + " WHERE " + eventDate + " = ?";
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(query, new String[]{selectedDate});
    }

    // Get all events using cursor data
    public Cursor getAllEvents() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM " + tableName, null);
    }

}
