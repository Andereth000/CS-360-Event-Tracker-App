package com.example.project_two_ethan_anderson;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;

// Popup information
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Database
    private CredentialDB cdb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Initialize buttons and text
        Button login = findViewById(R.id.login);
        Button createAccount = findViewById(R.id.createAccount);
        TextView forgotPassword = findViewById(R.id.forgotPassword);

        final EditText usernameText = findViewById(R.id.username);
        final EditText passwordText = findViewById(R.id.password);

        // Initialize database
        cdb = new CredentialDB(this);

        // Set click listener for forgot password
        forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Sorry!", Toast.LENGTH_SHORT).show();
            }
        });

        // Set click listener for createAccount
        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String username = usernameText.getText().toString();
                final String password = passwordText.getText().toString();
                cdb.createUser(username, password, cdb.getWritableDatabase(),
                        getApplicationContext());
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Set click listener for login
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String username = usernameText.getText().toString();
                final String password = passwordText.getText().toString();

                boolean loggedIn = cdb.verifyUser(username, password, cdb.getReadableDatabase(),
                        getApplicationContext());

                if (loggedIn) {
                    Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(getApplicationContext(), "Invalid username or password",
                            Toast.LENGTH_SHORT).show();
                }


            }
        });
    }

}

