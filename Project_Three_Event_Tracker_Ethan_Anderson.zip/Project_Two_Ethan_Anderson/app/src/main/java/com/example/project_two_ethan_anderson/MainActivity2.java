package com.example.project_two_ethan_anderson;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CalendarView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity2 extends AppCompatActivity {

    private ArrayList<String> eventsList;
    private ArrayAdapter<String> eventsAdapter;
    private EventDB edb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        // Get the current date
        CalendarView calendarView = findViewById(R.id.calendarView);
        TextView daySelected = findViewById(R.id.daySelected);
        Calendar calendar = Calendar.getInstance();
        Date date = calendar.getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("M/dd/yyyy", Locale.getDefault());
        String formattedDate = dateFormat.format(date);
        String selectedDateText = "Selected date: " + formattedDate;
        // Set the initial text
        daySelected.setText(selectedDateText);

        // Initialize EventDB instance
        edb = new EventDB(this);

        // Send SMS for upcoming event
        notifyUpcomingEvent(formattedDate);

        // Initialize ListView
        ListView eventsListView = findViewById(R.id.listView);

        // Initialize eventsList and Adapter
        eventsList = new ArrayList<>();
        eventsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,
                eventsList);
        eventsListView.setAdapter(eventsAdapter);

        // Load events for the current
        loadEvents(formattedDate);

        // Pass data between activities
        Intent intent = new Intent(MainActivity2.this, dialog_add_events.class);
        intent.putExtra("selectedDate", formattedDate);

        // Set click listener for ListView
        eventsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String eventNameToDelete = eventsList.get(position);
                deleteEvent(eventNameToDelete);
            }
        });

        // Set date change listener for CalendarView
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month,
                                            int dayOfMonth) {

                int displayMonth = month + 1;

                String selectedDate = displayMonth + "/" + dayOfMonth + "/" + year;

                Toast.makeText(MainActivity2.this, "Selected date: "
                        + selectedDate, Toast.LENGTH_SHORT).show();

                String selectedDateText = "Selected date: " + selectedDate;

                daySelected.setText(selectedDateText);

                loadEvents(selectedDate);

                intent.putExtra("selectedDate", selectedDate);
            }
        });

        // Set click listener for ListView
        eventsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String eventName = eventsList.get(position);
                showEditDeleteDialog(eventName);
            }
        });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize ImageButton
        ImageButton enableNotifications = findViewById(R.id.enable_notifications);
        ImageButton addEvent = findViewById(R.id.addEvent);

        // Set click listener for ImageButton
        enableNotifications.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity2.this, MainActivity3.class));
            }
        });

        // Set click listener for ImageButton
        addEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add event dialog
                startActivity(intent);
            }
        });

    }

    // Show alert dialog to edit or delete event
    public void showEditDeleteDialog(String eventName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit or Delete Event");
        builder.setItems(new CharSequence[]{"Edit", "Delete"}, (dialog, which) -> {
            switch (which) {
                case 0:
                    editEvent(eventName);
                    break;
                case 1:
                    deleteEvent(eventName);
                    break;
            }
        });
        builder.show();
    }

    // Load events for the selected date on calendar
    public void loadEvents(String selectedDate) {
        eventsList.clear();
        Cursor cursor = edb.getEventsByDate(selectedDate);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String eventName = cursor.getString(cursor.getColumnIndex("event_name"));
                eventsList.add(eventName);
            } while (cursor.moveToNext());

            cursor.close();
        }

        eventsAdapter.notifyDataSetChanged();
    }

    // Edit event logic
    public void editEvent(String eventName) {
        Intent editEventIntent = new Intent(MainActivity2.this, dialog_edit_event.class);
        editEventIntent.putExtra("eventName", eventName);
        // Start the edit event activity
        startActivityForResult(editEventIntent, 1);
    }

    // Delete event logic
    private void deleteEvent(String eventName) {

        SQLiteDatabase db = edb.getWritableDatabase();
        db.delete(EventDB.tableName, "event_name = ?", new String[]{eventName});
        db.close();

        eventsList.remove(eventName);
        eventsAdapter.notifyDataSetChanged();
    }

    // Handle the result of the edit event activity
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            String oldEventName = data.getStringExtra("oldEventName");
            String newEventName = data.getStringExtra("newEventName");

            // Update the event name in the list
            int index = eventsList.indexOf(oldEventName);
            if (index != -1) {
                eventsList.set(index, newEventName);
                eventsAdapter.notifyDataSetChanged();
            }
        }
    }

    // Send SMS notification on day of event
    private void notifyUpcomingEvent(String formattedDate) {
        // Get all events for the formattedDate
        Cursor cursor = edb.getAllEvents();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String eventDate = cursor.getString(cursor.getColumnIndex("event_date"));
                String eventName = cursor.getString(cursor.getColumnIndex("event_name"));

                // Check if eventDate matches the formattedDate
                if (eventDate.equals(formattedDate)) {
                    // getDefault method deprecated, used getSystemService() instead
                    String phoneNumber = "+15551234567";
                    String message = "You have an upcoming event scheduled today: " + eventName;

                    SmsManager smsManager = MainActivity2.this.getSystemService(SmsManager.class);
                    smsManager.sendTextMessage(phoneNumber, null,
                            message, null, null);
                }
            } while (cursor.moveToNext());

            cursor.close();
        }

        // Check for permission
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            Log.d("Event Tracker", "Permission is not granted, requesting");
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.SEND_SMS}, 123);
        } else {
            Log.d("Event Tracker", "Permission is granted");
        }
    }

    // Handle the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 123) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("Event Tracker", "Permission has been granted");

            } else {
                Log.d("Event Tracker", "Permission has been denied or request cancelled");

            }
        }
    }
}
