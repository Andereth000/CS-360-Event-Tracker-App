package com.example.project_two_ethan_anderson;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {

    TextView textView;
    EditText editTextPhone;
    EditText editTextMessage;
    Button sendSMS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main3);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button back1 = findViewById(R.id.back_1);

        back1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Go to previous activity
                finish();
            }
        });

        // Get text
        TextView textView = findViewById(R.id.forgot_password);
        EditText editTextPhone = findViewById(R.id.phone_number);
        EditText editTextMessage = findViewById(R.id.message);

        // Get the button
        Button sendSMS = findViewById(R.id.send_sms);

        // Send SMS on click
        sendSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    // getDefault method deprecated, used getSystemService() instead
                    SmsManager smsManager = MainActivity3.this.getSystemService(SmsManager.class);
                    smsManager.sendTextMessage(
                            editTextPhone.getText().toString(),
                            null,
                            editTextMessage.getText().toString(),
                            null,
                            null);

                    textView.setText("SMS sent");
                } catch (Exception e) {
                    textView.setText("SMS failed");
                }
            }
        });

        // Check for permission
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            Log.d("Event Tracker", "Permission is not granted, requesting");
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.SEND_SMS}, 123);
            sendSMS.setEnabled(false);
        } else {
            Log.d("Event Tracker", "Permission is granted");
        }
    }

    // Handle the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 123) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("Event Tracker", "Permission has been granted");
                textView.setText("You can send SMS!");
                sendSMS.setEnabled(true);
            } else {
                Log.d("Event Tracker", "Permission has been denied or request cancelled");
                textView.setText("You can not send SMS!");
                sendSMS.setEnabled(false);
            }
        }
    }
}
