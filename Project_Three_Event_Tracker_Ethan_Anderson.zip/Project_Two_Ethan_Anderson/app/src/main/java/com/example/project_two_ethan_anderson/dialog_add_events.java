package com.example.project_two_ethan_anderson;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class dialog_add_events extends AppCompatActivity {

    // Database
    private EventDB edb;
    // MainActivity2
    private MainActivity2 ma2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dialog_add_events);

        Button save = findViewById(R.id.save);
        Button cancel = findViewById(R.id.cancel);

        final EditText eventNameText = findViewById(R.id.eventName);
        final TextView eventDateText = findViewById(R.id.eventDate);

        String selectedDate = getIntent().getStringExtra("selectedDate");
        String formattedDate = getIntent().getStringExtra("formattedDate");

        if (!(selectedDate == null)) {
            eventDateText.setText(selectedDate);
        } else {
            eventDateText.setText(formattedDate);
        }

        // Initialize db
        edb = new EventDB(this);

        // Add event when save is pressed and send SMS
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String eventName = eventNameText.getText().toString();

                // getDefault method deprecated, used getSystemService() instead
                String phoneNumber = "+15551234567";
                String message = "Your event: " + eventName + " is scheduled for " + selectedDate;

                SmsManager smsManager = dialog_add_events.this.getSystemService(SmsManager.class);
                smsManager.sendTextMessage(phoneNumber, null, message,
                        null, null);

                edb.addEvent(eventName, selectedDate, edb.getWritableDatabase(),
                        getApplicationContext());
                ma2.loadEvents(selectedDate);
            }
        });

        // Check for sms permission
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            Log.d("Event Tracker", "Permission is not granted, requesting");
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.SEND_SMS}, 123);
        } else {
            Log.d("Event Tracker", "Permission is granted");
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.addEvent), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Cancel adding event
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Go to previous activity
                finish();
            }
        });
    }

    // Handle the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 123) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("Event Tracker", "Permission has been granted");

            } else {
                Log.d("Event Tracker", "Permission has been denied or request cancelled");

            }
        }
    }
}