package com.example.project_two_ethan_anderson;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class dialog_edit_event extends AppCompatActivity {

    // Database
    private EventDB edb;
    // MainActivity2
    private MainActivity2 ma2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dialog_edit_event);

        // Initialize database
        edb = new EventDB(this);

        // Initialize buttons
        Button save = findViewById(R.id.saveEdit);
        Button cancel = findViewById(R.id.cancelEdit);

        // Get event name from MainActivity2
        String oldEventName = getIntent().getStringExtra("eventName");

        // Set event name in EditText
        EditText eventNameText = findViewById(R.id.editEventName);
        eventNameText.setText(oldEventName);

        // Save edited event on click
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Save edited event
                String newEventName = eventNameText.getText().toString();
                edb.updateEvent(oldEventName, newEventName);

                // Pass new event name to MainActivity2
                Intent resultIntent = new Intent();
                resultIntent.putExtra("oldEventName", oldEventName);
                resultIntent.putExtra("newEventName", newEventName);
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.editEvent), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Cancel editing event
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Go to previous activity
                finish();
            }
        });
    }
}